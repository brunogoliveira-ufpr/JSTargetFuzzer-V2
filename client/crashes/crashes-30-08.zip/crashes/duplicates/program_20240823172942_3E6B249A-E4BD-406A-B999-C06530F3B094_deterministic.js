/[8g\p{Script_Extensions=Greek}]/ysvi;
// CRASH INFO
// ==========
// TERMSIG: 11
// STDERR:
// 
// STDOUT:
// 
// FUZZER ARGS: .build/x86_64-unknown-linux-gnu/debug/FuzzilliCli --use-math --use-object-array --use-read-write --profile=jsc /home/kali/PhD/JSEs/JavaScriptCore/Debug/bin/jsc --resume --storagePath=./crashes-jsc/
// TARGET ARGS: /home/kali/PhD/JSEs/JavaScriptCore/Debug/bin/jsc --validateOptions=true --thresholdForJITSoon=10 --thresholdForJITAfterWarmUp=10 --thresholdForOptimizeAfterWarmUp=100 --thresholdForOptimizeAfterLongWarmUp=100 --thresholdForOptimizeSoon=100 --thresholdForFTLOptimizeAfterWarmUp=1000 --thresholdForFTLOptimizeSoon=1000 --validateBCE=true --reprl
// CONTRIBUTORS: ReassignmentGenerator, PrototypeAccessGenerator, NumberComputationGenerator, IntArrayGenerator, PropertyRetrievalGenerator, ClassConstructorGenerator, ClassDefinitionGenerator, IntegerGenerator, RegExpGenerator, ClassInstanceElementGenerator, ComplexStructMutator, ClassInstanceMethodGenerator, ElementAssignmentGenerator, SuperPropertyUpdateGenerator, ClassPrivateInstancePropertyGenerator, PrivatePropertyRetrievalGenerator, SuperPropertyAssignmentGenerator
// EXECUTION TIME: 44ms
gc();
