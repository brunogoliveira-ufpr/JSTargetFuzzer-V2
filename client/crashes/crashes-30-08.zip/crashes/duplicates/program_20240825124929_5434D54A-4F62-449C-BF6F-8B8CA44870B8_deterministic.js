/[\p{Script_Extensions=Greek}a[a-z][a\Sg]]/ivg;
// CRASH INFO
// ==========
// TERMSIG: 11
// STDERR:
// 
// STDOUT:
// 
// FUZZER ARGS: .build/x86_64-unknown-linux-gnu/debug/FuzzilliCli --use-object-array --use-math --use-read-write --profile=jsc /home/kali/PhD/JSEs/JavaScriptCore/Debug/bin/jsc --resume --storagePath=./crashes-jsc
// TARGET ARGS: /home/kali/PhD/JSEs/JavaScriptCore/Debug/bin/jsc --validateOptions=true --thresholdForJITSoon=10 --thresholdForJITAfterWarmUp=10 --thresholdForOptimizeAfterWarmUp=100 --thresholdForOptimizeAfterLongWarmUp=100 --thresholdForOptimizeSoon=100 --thresholdForFTLOptimizeAfterWarmUp=1000 --thresholdForFTLOptimizeSoon=1000 --validateBCE=true --reprl
// CONTRIBUTORS: FloatArrayGenerator, IntegerGenerator, IntArrayGenerator, RegExpGenerator, ExplorationMutator
// EXECUTION TIME: 43ms
gc();
